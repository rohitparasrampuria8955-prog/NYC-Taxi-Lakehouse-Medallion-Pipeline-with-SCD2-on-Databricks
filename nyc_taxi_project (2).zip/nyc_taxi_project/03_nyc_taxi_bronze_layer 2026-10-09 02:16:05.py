# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "6"
# ///
# MAGIC %run ./02_setup_unity_catalog

# COMMAND ----------

from pyspark.sql import functions as F

df_bronze = (
    spark.readStream
    .format("cloudFiles")
    .option("cloudFiles.format", "parquet")
    .option("cloudFiles.schemaEvolutionMode", "addNewColumns")
    .option("cloudFiles.schemaLocation", f"{VOLUME_ROOT}/_SCHEMA/trips")
    .load(RAW_TRIPS)
)





# COMMAND ----------

df_bronze = (
    df_bronze
    .withColumn("_ingest_time", F.current_timestamp())
    .withColumn("_source_file", F.col("_metadata.file_name"))
    .withColumn("_process_ingestion",F.lit("Auto_loader"))
)

# COMMAND ----------

# DBTITLE 1,Cell 5
df_bronze.writeStream\
.format("delta")\
.option(
    "checkpointLocation",
    f"{VOLUME_ROOT}/checkpoints/bronze_trips/"
)\
.option("mergeSchema", "true")\
.outputMode("append")\
.trigger(availableNow=True)\
.toTable(T_BRONZE_TRIPS)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from nyc_taxi.bronze.bronze_trips

# COMMAND ----------

df_silver = spark.readStream.table(T_BRONZE_TRIPS)

# COMMAND ----------

df_silver = df_silver.withColumn("encrpted_value",F.sha2(F.concat_ws("||",F.col("VendorID"),F.col("tpep_pickup_datetime"),F.col("tpep_dropoff_datetime"),F.col("total_amount"),F.col("trip_distance"),F.col("PULocationID"),F.col("DOLocationID")),256))

# COMMAND ----------

df_silver = df_silver.dropDuplicates(["encrpted_value"])

# COMMAND ----------

df_silver.writeStream \
    .format("delta") \
    .option(
        "checkpointLocation",
        f"{VOLUME_ROOT}/checkpoints/silver/"
    ) \
    .outputMode("append") \
    .trigger(availableNow=True) \
    .toTable(T_SILVER_TRIPS)

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM nyc_taxi.silver.trips;

# COMMAND ----------

import pyspark.sql.functions as F

# COMMAND ----------

df_bronze_zone = (
    spark.readStream
    .format("cloudFiles")
    .option("cloudFiles.format", "csv")
    .option("header", "true")
    .option("cloudFiles.schemaEvolutionMode", "addNewColumns")
    .option("cloudFiles.schemaLocation", f"{VOLUME_ROOT}/schema2/raw_zone/")
    .load(RAW_ZONE)
)

# COMMAND ----------

df_bronze_zone = (
    df_bronze_zone
    .withColumn("_ingest_time", F.current_timestamp())
    .withColumn("_source_file", F.col("_metadata.file_name"))
    .withColumn("_process_ingestion",F.lit("Auto_loader"))
)


# COMMAND ----------

df_bronze_zone.writeStream\
.format("delta")\
.option(
    "checkpointLocation",
    f"{VOLUME_ROOT}/checkpoints1/bronze_zone/"
)\
.option("mergeSchema", "true")\
.outputMode("append")\
.trigger(availableNow=True)\
.toTable(T_BRONZE_ZONE)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from nyc_taxi.bronze.bronze_zone

# COMMAND ----------

df_silver_zone = spark.readStream.table(T_BRONZE_ZONE)





# COMMAND ----------

df_silver_zone = df_silver_zone.withColumn("encrpted_value",F.sha2(F.concat_ws("||",F.col("LocationID"),F.col("Borough"),F.col("Zone"),F.col("service_zone")),256))

# COMMAND ----------

df_silver_zone = df_silver_zone.dropDuplicates(["encrpted_value"])

# COMMAND ----------

df_silver_zone.writeStream \
    .format("delta") \
    .option(
        "checkpointLocation",
        f"{VOLUME_ROOT}/checkpoints1/silver_zone/"
    ) \
    .outputMode("append") \
    .trigger(availableNow=True) \
    .toTable(T_SILVER_ZONE)

# COMMAND ----------

# MAGIC
# MAGIC
# MAGIC %sql
# MAGIC select * from nyc_taxi.silver.zone