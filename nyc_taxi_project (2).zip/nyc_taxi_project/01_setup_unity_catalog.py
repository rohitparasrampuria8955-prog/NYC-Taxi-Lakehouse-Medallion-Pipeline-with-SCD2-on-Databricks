# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "6"
# ///


CATALOG = "nyc_taxi_project"

# COMMAND ----------

USE_PREFIXED_SCHEMAS = (CATALOG == "workspace")

# COMMAND ----------

def _Schema(name):
    if USE_PREFIXED_SCHEMAS:
        return f"nyc_{name}"
    else:
        return name

# COMMAND ----------

LANDING_SCHEMA = _Schema("landing")
BRONZE_SCHEMA = _Schema("bronze")
SILVER_SCHEMA = _Schema("silver")
GOLD_SCHEMA = _Schema("gold")

# COMMAND ----------

print(LANDING_SCHEMA)

# COMMAND ----------

VOLUME = "datafiles"
VOLUME_ROOT = f"/Volumes/{CATALOG}/{LANDING_SCHEMA}/{VOLUME}"
RAW_TRIPS = f"{VOLUME_ROOT}/raw_trips"
RAW_ZONE = f"{VOLUME_ROOT}/raw_zone"


# COMMAND ----------

print(VOLUME_ROOT)
print(RAW_TRIPS)
print(RAW_ZONE)

# COMMAND ----------

# ============================================================
# CENTRAL TABLE / VIEW VARIABLES
# Use these variables in all downstream notebooks instead of
# hardcoding catalog.schema.table names.
# ============================================================

# Bronze layer
T_BRONZE_TRIPS = f"{CATALOG}.{BRONZE_SCHEMA}.bronze_trips"
T_BRONZE_ZONE = f"{CATALOG}.{BRONZE_SCHEMA}.bronze_zone"
# Backward-compatible alias for notebooks that use the plural name.
T_BRONZE_ZONES = T_BRONZE_ZONE

# Silver layer
T_SILVER_TRIPS = f"{CATALOG}.{SILVER_SCHEMA}.silver_trips"
T_SILVER_ZONE = f"{CATALOG}.{SILVER_SCHEMA}.silver_zone"
T_SILVER_QUARANTINE = f"{CATALOG}.{SILVER_SCHEMA}.trips_quarantine"
T_SILVER_ZONE_STG = f"{CATALOG}.{SILVER_SCHEMA}.zone_stg"
T_SILVER_TRIPS_STG = f"{CATALOG}.{SILVER_SCHEMA}.trips_stg"

# Gold dimensions
T_DIM_DATE = f"{CATALOG}.{GOLD_SCHEMA}.t_dim_date"
T_DIM_ZONE = f"{CATALOG}.{GOLD_SCHEMA}.t_dim_zone"
T_DIM_VENDOR = f"{CATALOG}.{GOLD_SCHEMA}.dim_vendor"
T_DIM_PAYMENT = f"{CATALOG}.{GOLD_SCHEMA}.dim_payment"
T_DIM_RATE = f"{CATALOG}.{GOLD_SCHEMA}.dim_rate"

# Gold fact table and watermark/control table
T_FACT_TRIPS = f"{CATALOG}.{GOLD_SCHEMA}.fact_trips"
T_WATERMARK = f"{CATALOG}.{GOLD_SCHEMA}.pipeline_watermark"

# Gold dashboard marts and health view
T_MART_DAILY_KPIS = f"{CATALOG}.{GOLD_SCHEMA}.mart_daily_kpis"
T_MART_HOURLY_DEMAND = f"{CATALOG}.{GOLD_SCHEMA}.mart_hourly_demand"
T_MART_ZONE_PERFORMANCE = f"{CATALOG}.{GOLD_SCHEMA}.mart_zone_performance"
T_MART_PAYMENT_MIX = f"{CATALOG}.{GOLD_SCHEMA}.mart_payment_mix"
T_MART_VENDOR_SCORECARD = f"{CATALOG}.{GOLD_SCHEMA}.mart_vendor_scorecard"
T_VW_PIPELINE_HEALTH = f"{CATALOG}.{GOLD_SCHEMA}.vw_pipeline_health"

# Data-quality checks table list (handy for orchestration / inspection)
T_DATA_QUALITY_RESULTS = f"{CATALOG}.{GOLD_SCHEMA}.data_quality_results"