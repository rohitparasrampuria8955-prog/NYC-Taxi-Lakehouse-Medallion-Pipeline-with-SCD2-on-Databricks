# Databricks notebook source
# /// script
# [tool.databricks.environment]
# environment_version = "6"
# ///
# DBTITLE 1,Import configuration from setup_unity_catalog
# MAGIC %run ./01_setup_unity_catalog

# COMMAND ----------

print(LANDING_SCHEMA)

# COMMAND ----------

spark.sql(f"CREATE CATALOG IF NOT EXISTS {CATALOG}")
spark.sql(f"USE CATALOG {CATALOG}")

# COMMAND ----------

cataloglist = [LANDING_SCHEMA,BRONZE_SCHEMA,SILVER_SCHEMA,GOLD_SCHEMA]

# COMMAND ----------

for c in cataloglist:
  spark.sql(f"CREATE SCHEMA IF NOT EXISTS {c}")

  spark.sql(f"CREATE VOLUME IF NOT EXISTS {CATALOG}.{LANDING_SCHEMA}.{VOLUME}")
  

# COMMAND ----------

directory_list = [RAW_TRIPS,RAW_ZONE]

for d in directory_list:
  dbutils.fs.mkdirs(d)

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC